function logOut(element) {
    element.innerText = "Logout";
}

function hide(element) {
    element.remove();
}

function clickThis(element) {
    alert("Ninja was liked\n\n Ok")
}